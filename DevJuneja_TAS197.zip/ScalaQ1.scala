object ScalaQ1 {
    def bucketize(arr: Array[Double]): Array[String] = {
        arr.map { value =>
            val bucketStart = (Math.floor(value * 20) / 20) // Round down to two decimal places
            f"$bucketStart%.3f - ${bucketStart + 0.049}%.3f"
        }
    }

    def main(args: Array[String]) = {
        val sampleArray = Array(12.05, 12.03, 10.33, 11.45, 13.50, 100.55)
        val output = bucketize(sampleArray)
        println(output.mkString(", "))
    }
}



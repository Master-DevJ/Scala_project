case class Player(
    year: Int, 
    playerName: String, 
    country: String, 
    matches: Int, 
    runs: Int, 
    wickets: Int
)

object ScalaQ2{
    def main(args : Array[String]) = {
        val players = List(
            Player(2021, "Sam", "India", 23, 2300, 3),
            Player(2021, "Ram", "India", 23, 300, 30),
            Player(2021, "Manoo", "India", 23, 300, 13),
            Player(2021, "Saam", "India", 23, 2300, 39),
            Player(2021, "Raam", "India", 23, 390, 30),
            Player(2021, "Mano", "India", 23, 5300, 11)
        )

        // 1. Player with the highest run scored
        val playerWithHighestRuns = players.maxBy(_.runs)
        println(s"\nPlayer with the highest run scored: ${playerWithHighestRuns.playerName}")
        println("\n ------------------------------------------------------------------------------------------------------")

        // 2. Top 5 players by run scored
        val top5PlayersByRuns = players.sortBy(- _.runs).take(5)
        println("Top 5 players by run scored:")
        top5PlayersByRuns.foreach(p => println(s"${p.playerName}: ${p.runs} runs"))
        println("\n ------------------------------------------------------------------------------------------------------")

        // 3. Top 5 players by wickets taken
        val top5PlayersByWickets = players.sortBy(- _.wickets).take(5)
        println("Top 5 players by wickets taken:")
        top5PlayersByWickets.foreach(p => println(s"${p.playerName}: ${p.wickets} wickets"))
        println("\n ------------------------------------------------------------------------------------------------------")

        // 4. Rank players with overall performance
        val rankedPlayers = players.map(p => (p, p.runs * 5 / 100 + p.wickets * 5)).sortBy(- _._2)
        println("Rank players with overall performance (weighted):")
        rankedPlayers.zipWithIndex.foreach { case ((player, score), index) =>
            println(s"${index + 1}. ${player.playerName} - Score: $score")
        }
        println("\n ------------------------------------------------------------------------------------------------------")
    }
}
